<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
    private $primarykey="id";
    protected $guarded = [];
}
