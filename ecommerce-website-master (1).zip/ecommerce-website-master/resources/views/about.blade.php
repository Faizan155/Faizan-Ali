@extends('layouts.template')


@section('content')
    <h1>About Page </h1>
@endsection
