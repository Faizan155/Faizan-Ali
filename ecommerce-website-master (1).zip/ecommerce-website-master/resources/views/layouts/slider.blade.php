
    <div class="jumbotron">
        <h1>Featured Content</h1>
        <p class="lead">This example is a quick exercise to illustrate how fixed to top navbar works. As you scroll, it will remain fixed to the top of your browser's viewport.</p>
        <a class="btn btn-lg btn-primary" href="#" role="button">Checkout &raquo;</a>
    </div>

